
const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("optionText"));
const progressText = document.getElementById("progressText");
const scoreText = document.getElementById("score");
const progressBarFull = document.getElementById("progressBarFull");
let currentQuestion = {};
let acceptingAnswers = false;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
   { question : "The IDE used in swift is ?",
    choice1 : "Swiftc",
    choice2 : "Gas",
    choice3 : "Xcode",
    choice4 : "Ld",
    answer : 3
   },
    {
      question : "Which of the following IOS Framework is a commonly used in third party library?",
    choice1 : "AVFoundation.framework",
    choice2 : "Audiotoolbox.framework",
    choice3 : "AFNetwork.framework",
    choice4 : "None",
    answer : 3
    },
    {
     question : "Double has a precision of at Least_Decimal digits in swift ?",
    choice1 : "15",
    choice2 : "20",
    choice3 : "17",
    choice4 : "10",
    answer : 1
  },
  {
    question : "We can return multiple values in swift from function by using?",
  choice1 : "Array",
  choice2 : "Tuples",
  choice3 : "Both",
  choice4 : "None",
  answer : 2
  },
  {
    question : "which of the following is incorrect Data Type in swift?",
  choice1 : "UInt",
  choice2 : "Double",
  choice3 : "Char",
  choice4 : "Optional",
  answer : 3
  },
  {
    question : "The most recent version of macOS is based on?",
  choice1 : "Window",
  choice2 : "Linux",
  choice3 : "UNIX",
  choice4 : "CMOS",
  answer : 3
  },
  {
    question : "To initialize variable with null require?",
  choice1 : "?",
  choice2 : "!",
  choice3 : "-",
  choice4 : "NULL",
  answer : 1
  },
  {
    question : "For unwrapping value inside optional what should we use ?",
  choice1 : "?",
  choice2 : "@",
  choice3 : "!",
  choice4 : "None",
  answer : 3
  },
  {
    question : "which of the following  Framework is not used in IOS?",
  choice1 : "UIKit Framework",
  choice2 : "AppKit Framework",
  choice3 : "Foundation Framework",
  choice4 : "CoreMotion Framework",
  answer : 2
  },
  {
    question : "which of the following declares a mutable array in swift?",
  choice1 : "let x = [Int]()",
  choice2 : "var x = [Int]",
  choice3 : "var x = [Int]()",
  choice4 : "let x = [Int]",
  answer : 3
},
{ question : "What is Bundle in IOS ?",
 choice1 : "It is a class",
 choice2 : "It is used to send data",
 choice3 : "It is folder with .app extension",
 choice4 : "None",
 answer : 3
},
 {
   question : "Which of the following IOS Framework is a commonly used in third party library?",
 choice1 : "AVFoundation.framework",
 choice2 : "Audiotoolbox.framework",
 choice3 : "AFNetwork.framework",
 choice4 : "None",
 answer : 3
 },
 {
  question : "IOS stand for ?",
 choice1 : "Internet Operating system",
 choice2 : "Internetwork Operating System",
 choice3 : "Iphone Operating System",
 choice4 : "None",
 answer : 3
},
{
 question : "Application running in foreground but currently not receving any events. What is the current state of application?",
choice1 : "Inactive State",
choice2 : "Active State",
choice3 : "Suspended State",
choice4 : "Background State",
answer : 1
},
{
 question : "What is face time in Apple?",
choice1 : "Taking Videos",
choice2 : "Digital Photos",
choice3 : "Video Calls",
choice4 : "Editing Photos",
answer : 3
},
{
 question : "Multitasking in IOS was introduced in which version?",
choice1 : "ios 6.0",
choice2 : "ios 2.0",
choice3 : "ios 4.0",
choice4 : "ios 7.0",
answer : 3
},
{
 question : "The _______ file specifies the layout of your screen?",
choice1 : "String XML ",
choice2 : "Layout file",
choice3 : "Mainfest file",
choice4 : "R file",
answer : 2
},
{
 question : "The Iphone has a feature that activities when you rotate the device from portrait to landscape.",
choice1 : "shadow detector",
choice2 : "Rotator",
choice3 : "Accelerometer",
choice4 : "Special Sensor",
answer : 3
},
{
 question : "Flash Application are supported in Iphone browsers?",
choice1 : "It supports flash applications from apple only",
choice2 : "Yes",
choice3 : "No",
choice4 : "Supports partially",
answer : 2
},
{
 question : "The Iphone camera can?",
choice1 : "Record videos",
choice2 : "Zoom",
choice3 : "Autofocus",
choice4 : "Make digital photos",
answer : 4
}
];

//constants
const CORRECT_BONUS = 1;
const MAX_QUESTIONS = 10;

startGame = () => {
    questionCounter = 0;
    score = 0;
    availableQuestions = [...questions];
    console.log(availableQuestions);
    getNewQuestion();
};

getNewQuestion = () => {
    if(availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS){
      localStorage.setItem("mostRecentScore", score);
        //go to the end page
        return window.location.assign("IOS.html");
    }
    questionCounter++;
    progressText.innerText = `Question ${questionCounter}/${MAX_QUESTIONS}`;
    //update the progress bar
    progressBarFull.style.width = `${(questionCounter/MAX_QUESTIONS)*100}%`;
    const questionIndex = Math.floor(Math.random() * availableQuestions.length);
    currentQuestion = availableQuestions[questionIndex];
    question.innerText = currentQuestion.question;

    choices.forEach(choice => {
        const number = choice.dataset["number"];
        choice.innerText = currentQuestion["choice" + number];
    });
    availableQuestions.splice(questionIndex, 1);
    acceptingAnswers = true;
};

choices.forEach(choice => {
    choice.addEventListener("click", e =>{
        if(!acceptingAnswers) return;
        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset["number"];
        const classToApply = selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';
        if(classToApply === "correct"){
          incrementScore(CORRECT_BONUS);
        }
      selectedChoice.parentElement.classList.add(classToApply);
        setTimeout(() => {
        selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        },1000);

    });
});


incrementScore = num =>{
  score += num;
  scoreText.innerText = score;
};
startGame();
